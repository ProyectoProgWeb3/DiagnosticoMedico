<?php
include_once("EmpresasCollector.php");

$id =1;

$EmpresasCollectorObj = new EmpresasCollector();

foreach ($EmpresasCollectorObj->showEmpres() as $c){
  echo "<div>";
  echo $c->getidempresas() . "  && " .$c->getnombre();                                     
  echo "</div>"; 
}


?>
