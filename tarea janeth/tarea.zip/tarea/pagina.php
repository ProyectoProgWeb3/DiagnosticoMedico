<?php
include_once("DemoCollector.php");


$DemoCollectorObj = new DemoCollector();

foreach ($DemoCollectorObj->showDemos() as $c){
  echo "<div>";
  echo $c->getcodpaciente(). "  && " .$c->getlogin();                                     
  echo "</div>"; 
}


?>

