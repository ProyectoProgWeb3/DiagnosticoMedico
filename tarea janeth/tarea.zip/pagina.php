<?php
include_once("PacienteCollector.php");


$PacienteCollectorObj = new PacienteCollector();

foreach ($PacienteCollectorObj->showDemos() as $c){
  echo "<div>";
  echo $c->getcodpaciente(). "  && " .$c->getlogin();                                     
  echo "</div>"; 
}


?>

