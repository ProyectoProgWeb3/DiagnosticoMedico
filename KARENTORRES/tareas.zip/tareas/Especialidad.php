<?php

class Especialidad
{
    private $codigo;
    private $detalle;
    
     function __construct($codigo, $detalle){
       $this->codigo = $codigo;
       $this->detalle= $detalle;
   
     }
    
     function setcodigo($codigo){
       $this->codigo = $codigo;
     } 
     
     function getcodigo(){
       return $this->codigo;
     } 
     
    function setdetalle($detalle){
       $this->detalle = $detalle;
     } 
     
     function getdetalle(){
       return $this->detalle;
     }      
   
}

?> 

