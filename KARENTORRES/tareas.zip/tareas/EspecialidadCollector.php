<?php

include_once('Especialidad.php');
include_once('Collector.php');

class EspecialidadCollector extends Collector
{
  
  function showEspecialidads() {
    $rows = self::$db->getRows("SELECT * FROM especialidad");        
    $arrayEspecialidad= array();        
    foreach ($rows as $c){
      $aux = new Especialidad($c{'codigo'},$c{'detalle'});
      array_push($arrayEspecialidad, $aux);
    }
    return $arrayEspecialidad;        
  }

    

}
?>



