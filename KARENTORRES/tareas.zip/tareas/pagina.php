<?php
include_once("EspecialidadCollector.php");


$EspecialidadCollectorObj = new EspecialidadCollector();

foreach ($EspecialidadCollectorObj->showEspecialidads() as $c){
  echo "<div>";
  echo $c->getcodigo(). "  && " .$c->getdetalle();                                     
  echo "</div>"; 
}


?>

