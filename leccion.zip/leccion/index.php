
<html>
<?php include('metadato.php');?>
<body>		
	<div class="clear"></div>

	<div class="clear">
	
		
			<table class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Id</th>
                <th>Nombre</th>
                <th>Nota</th>
                <th>Nota</th>
                <th>Promedio</th>
              </tr>
            </thead>
            <tbody>
                <tr>
                <td>1</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
              <td>2</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
               <tr>
                <td>3</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tbody>
          </table>
          </div>


		<?php
		include_once("calificacionesCollector.php");

			$calificacionCollectorObj = new calificacionesCollector();

			

				foreach ($calificacionCollectorObj->showCalificaciones() as $c){
				    echo "<div>";
				  echo "ID:".$c->getId()."<br>";
					echo "nombre:" .$c->getNombre()."<br>"."<br>";
					echo "nota1:" .$c->getParcial()."<br>"."<br>";
					echo "nota2:" .$c->getFinal()."<br>"."<br>";
					echo "promedio:" .$c->getMejoramiento()."<br>"."<br>";
          echo "promedio:" .$c->getNotaProm()."<br>"."<br>";                              
				  echo "</div>";
				}

		?>
</body>
</html>