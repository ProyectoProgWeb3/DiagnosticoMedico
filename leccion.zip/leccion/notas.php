<?php
class register
{
    public $nombre;
    public $parcial;
    public $final;
    public $mejoramiento;
    public $numrows;
    public $error;
    public $ok;
    public $regconsulta;

    public function __construct($nombre, $parcial, $final,  $mejoramiento)
    {
        include "config.php";
        $this->nombre        =    $nombre;
        $this->parcial        =    $parcial;
        $this->final    =    $final;
        $this->mejoramiento       =    $mejoramiento;
        $this->consulta        =    mysql_consulta("SELECT * FROM users WHERE usuario = '".$this->user."'");
        $this->numrows        =    mysql_num_rows($this->consulta);
        $this->error        =    "Nombre de estudiante incorrecto";
        $this->ok            =    "Te has registrado correctamente";
    }
    public function check()
    {
        if($this->numrows!=0)
        {
            die ($this->error);
        }
        if($this->nombre)
        {
            $register = mysql_consulta("INSERT INTO `users` (`id`, `nombre`, `parcial`, `final`, `mejoramiento`, `admin`) VALUES (NULL, '".$this->nombre."', '".$this->parcial."', '".$this->final."', '".$this->mejoramiento."', '0')");
             echo $this->ok;
            }
            else
            {
            echo $this->error;             
            }
    }
}
include_once "limpiar.php";
$reg = new register(clear($_POST['nombre']), clear($_POST['parcial']), clear($_POST['final']), clear($_POST['mejoramiento']));
echo $reg->check();
?>