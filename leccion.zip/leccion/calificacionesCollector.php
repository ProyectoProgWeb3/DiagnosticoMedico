<?php

include_once('calificacion.php');
include_once('Collector.php');

class calificacionesCollector extends Collector
{
  
  function showCalificaciones() {
    $rows = self::$db->getRows("SELECT * FROM notas ");        
    $arrayCalificaciones= array();        
    foreach ($rows as $c){
      $aux = new calificaciones($c{'id'},$c{'nombre'},$c{'parcial'},$c{'final'},$c{'mejoramiento'},$c{'notaProm'});
      array_push($arrayCalificaciones, $aux);
    }
    return $arrayCalificaciones;        
  }

}
?>

