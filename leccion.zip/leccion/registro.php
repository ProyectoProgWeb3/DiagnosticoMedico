<html>
<?php include('metadatos.php');?>
<body>
		
		<div class="contenedor_registro">
			<div class="row block05" align="center">
			
				<div class="titulo"><h2>Registro de Notas</h2></div>
				<div class="col-2-3">
					<div class="contenedor_registro">
						<article>
                            <form action="notas.php" method="post" name="contact">


                                <div class="nuevo_registro">
                                    

                                    <div class="leftCol">
									<table>
										<tr>
                                        <td><label for="nombre">Nombre</label></td>
                                        <td><input tabindex="1" type="text" name="nombre" id="nombre" class="txtBox" value="" /></td>
                                        
										</tr>
										
										<tr>
                                        <td><label for="parcial">Parcial</label></td>
                                        <td><input tabindex="3" type="text" name="parcial" id="parcial" class="txtBox" value="0-100" /></td>
                                        
										</tr>
										<tr>
                                        <td><label for="final">Final</label></td>
                                        <td><input tabindex="4" type="text" name="final" id="final" class="txtBox" value="0-100" /></td>
                                        
										</tr>
										<tr>
                                        <td><label for="mejoramiento">Mejoramiento</label></td>
                                        <td><input tabindex="5" type="text" name="mejoramiento" id="mejoramiento" class="txtBox" value="0-100" /></td>
                                        
										</tr>
										

                                    </div>
									
									</table>
                                </div>
                                <p align="center"><input type="submit" class="button" value="Enviar" name="submit"></p>
                            </form>
						</article>
					</div>
				</div>
						
			</div>		
			
	
			
		</div>
	
	
	
	
</div>
</body>
</html>