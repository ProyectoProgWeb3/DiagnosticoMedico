<?php
echo <<< HERE
  <html>

    
    <body>
    <div>

          <table class="table table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Id</th>
                <th>Nombre</th>
                <th>Nota</th>
                <th>Nota</th>
                <th>Promedio</th>
              </tr>
            </thead>
            <tbody>
                <tr>
                <td>1</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
              <tr>
              <td>2</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
               <tr>
                <td>3</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
    </div>    
    </body>
    </html>
HERE;

?>
